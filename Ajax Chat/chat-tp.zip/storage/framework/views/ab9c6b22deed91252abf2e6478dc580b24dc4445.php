<?php $__env->startSection('title', 'Support Teleperformance'); ?>

<?php $__env->startSection('content'); ?>

<div class="container pt-2" style="height: 100% !important;">
    <div class="row" style="height: 100% !important;">
        <div class="col-md-12" style="height: 100% !important;">
            <div class="row text-white" id="chat-wrapper" data-user-id="<?php echo e(Auth::user()->id); ?>" data-image-path="<?php echo e(asset('storage/')); ?>" data-audio-path="<?php echo e(asset('storage/')); ?>" style="height: 100% !important;">
                <div class="col-md-12" id="chat-body" style="height: 90%; overflow-y: auto;">
                    <div class="p-3 d-flex flex-column" id="messages-container" style="height: 100%;">
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($message->user_id == Auth::user()->id): ?>
                                <div class="bg-success text-light rounded p-2 mb-2" style="max-width: 60%; align-self: flex-end;">
                                    <?php echo nl2br(e($message->mesage)); ?>

                                    <?php if($message->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $message->image)); ?>" alt="Image" class="img-fluid mt-2">
                                    <?php endif; ?>
                                    <?php if($message->audio): ?>
                                        <audio controls class="mt-2">
                                            <source src="<?php echo e(asset('storage/' . $message->audio)); ?>" type="audio/mpeg">
                                            Your browser does not support the audio element.
                                        </audio>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="bg-secondary rounded p-2 mb-2 text-light" style="max-width: 60%; align-self: flex-start;">
                                    <?php echo nl2br(e($message->mesage)); ?>

                                    <?php if($message->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $message->image)); ?>" alt="Image" class="img-fluid mt-2">
                                    <?php endif; ?>
                                    <?php if($message->audio): ?>
                                        <audio controls class="mt-2">
                                            <source src="<?php echo e(asset('storage/' . $message->audio)); ?>" type="audio/mpeg">
                                            Your browser does not support the audio element.
                                        </audio>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-12 mt-2" id="chat-footer">
                    <form class="d-flex" id="chat-form" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="pe-2 w-100">
                            <textarea class="form-control" name="mesage" id="myTextarea" placeholder="Diga algo..." cols="30" rows="1"></textarea>
                        </div>
                        <label for="image" class="btn btn-secondary me-2 text-white">
                            <i class="fa-solid fa-image"></i>
                            <input type="file" name="image" id="image" accept="image/*" style="display: none;">
                        </label>
                        <label for="audio" class="btn btn-secondary me-2 text-white">
                            <i class="fa-solid fa-microphone"></i>
                            <input type="file" name="audio" id="audio" accept="audio/*" style="display: none;">
                        </label>
                        <button type="submit" class="btn btn-success text-white"><i class="fa-solid fa-play"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetos\laravel01\chat-tp\resources\views/chat/chat.blade.php ENDPATH**/ ?>