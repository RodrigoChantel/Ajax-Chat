<?php $__env->startSection('title', 'Support Teleperformance'); ?>

<?php $__env->startSection('content'); ?>
<div class="container pt-2" style="height: 100% !important;">
    <div class="row" style="height: 100% !important;">

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetos\laravel01\chat-tp\resources\views/welcome.blade.php ENDPATH**/ ?>