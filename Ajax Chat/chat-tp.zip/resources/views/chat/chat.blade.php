@extends('layouts.app')

@section('title', 'Support Teleperformance')

@section('content')

<div class="container pt-2" style="height: 100% !important;">
    <div class="row" style="height: 100% !important;">
        <div class="col-md-12" style="height: 100% !important;">
            <div class="row text-white" id="chat-wrapper" data-user-id="{{ Auth::user()->id }}" data-image-path="{{ asset('storage/') }}" data-audio-path="{{ asset('storage/') }}" style="height: 100% !important;">
                <div class="col-md-12" id="chat-body" style="height: 90%; overflow-y: auto;">
                    <div class="p-3 d-flex flex-column" id="messages-container" style="height: 100%;">
                        @foreach ($messages as $message)
                            @if ($message->user_id == Auth::user()->id)
                                <div class="bg-success text-light rounded p-2 mb-2" style="max-width: 60%; align-self: flex-end;">
                                    {!! nl2br(e($message->mesage)) !!}
                                    @if ($message->image)
                                        <img src="{{ asset('storage/' . $message->image) }}" alt="Image" class="img-fluid mt-2">
                                    @endif
                                    @if ($message->audio)
                                        <audio controls class="mt-2">
                                            <source src="{{ asset('storage/' . $message->audio) }}" type="audio/mpeg">
                                            Your browser does not support the audio element.
                                        </audio>
                                    @endif
                                </div>
                            @else
                                <div class="bg-secondary rounded p-2 mb-2 text-light" style="max-width: 60%; align-self: flex-start;">
                                    {!! nl2br(e($message->mesage)) !!}
                                    @if ($message->image)
                                        <img src="{{ asset('storage/' . $message->image) }}" alt="Image" class="img-fluid mt-2">
                                    @endif
                                    @if ($message->audio)
                                        <audio controls class="mt-2">
                                            <source src="{{ asset('storage/' . $message->audio) }}" type="audio/mpeg">
                                            Your browser does not support the audio element.
                                        </audio>
                                    @endif
                                </div>
                            @endif
                        @endforeach
                    </div>
                </div>
                <div class="col-md-12 mt-2" id="chat-footer">
                    <form class="d-flex" id="chat-form" enctype="multipart/form-data">
                        @csrf
                        <div class="pe-2 w-100">
                            <textarea class="form-control" name="mesage" id="myTextarea" placeholder="Diga algo..." cols="30" rows="1"></textarea>
                        </div>
                        <label for="image" class="btn btn-secondary me-2 text-white">
                            <i class="fa-solid fa-image"></i>
                            <input type="file" name="image" id="image" accept="image/*" style="display: none;">
                        </label>
                        <label for="audio" class="btn btn-secondary me-2 text-white">
                            <i class="fa-solid fa-microphone"></i>
                            <input type="file" name="audio" id="audio" accept="audio/*" style="display: none;">
                        </label>
                        <button type="submit" class="btn btn-success text-white"><i class="fa-solid fa-play"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

