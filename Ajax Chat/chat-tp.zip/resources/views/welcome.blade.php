@extends('layouts.app')

@section('title', 'Support Teleperformance')

@section('content')
<div class="container pt-2" style="height: 100% !important;">
    <div class="row" style="height: 100% !important;">

    </div>
</div>
@endsection

