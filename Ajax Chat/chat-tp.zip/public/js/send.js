$(document).ready(function() {
    console.log('send.js loaded'); // Verificar se o arquivo está sendo carregado

    var userId = $('#chat-wrapper').data('user-id');
    var imagePath = $('#chat-wrapper').data('image-path');
    var audioPath = $('#chat-wrapper').data('audio-path');

    $('#chat-form').on('submit', function(e) {
        e.preventDefault();
        console.log('Form submitted'); // Verificar se o evento submit está sendo capturado

        var formData = new FormData(this);

        $.ajax({
            url: $('meta[name="send-message-url"]').attr('content'),
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                console.log('Response received:', response); // Verificar se a resposta está sendo recebida
                if (response.errors) {
                    console.log(response.errors);
                } else {
                    $('#myTextarea').val('');
                    $('#image').val('');
                    $('#audio').val('');
                    appendMessage(response.message);
                }
            },
            error: function(xhr) {
                console.log(xhr.responseText);
            }
        });
    });

   // Inicializar Pusher
    const pusher = new Pusher('YOUR_PUSHER_APP_KEY', {
        cluster: 'YOUR_PUSHER_CLUSTER',
        encrypted: true
    });

    // Obter o usuário atual
    var userId = $('#chat-wrapper').data('user-id');
    var imagePath = $('#chat-wrapper').data('image-path');
    var audioPath = $('#chat-wrapper').data('audio-path');

    // Subscrever-se ao canal público Pusher
    const channel = pusher.subscribe('chat.' + userId);

    // Lidar com novas mensagens recebidas
    channel.bind('App\\Events\\NewMessage', function(data) {
        // Atualizar o chat com a nova mensagem recebida
        appendMessage(data.message);
    });

    function appendMessage(message) {
        var messageHtml = '';
        if (message.user_id == userId) {
            messageHtml += '<div class="bg-success text-light rounded p-2 mb-2" style="max-width: 60%; align-self: flex-end;">';
        } else {
            messageHtml += '<div class="bg-secondary text-light rounded p-2 mb-2" style="max-width: 60%;">';
        }
        messageHtml += nl2br(message.mesage);
        if (message.image) {
            messageHtml += '<img src="' + imagePath + '/' + message.image + '" alt="Image" class="img-fluid mt-2">';
        }
        if (message.audio) {
            messageHtml += '<audio controls class="mt-2"><source src="' + audioPath + '/' + message.audio + '" type="audio/mpeg">Your browser does not support the audio element.</audio>';
        }
        messageHtml += '</div>';

        $('#messages-container').append(messageHtml);
        $('#chat-body').scrollTop($('#chat-body')[0].scrollHeight);
    }

    function nl2br(str) {
        return str.replace(/\n/g, '<br>');
    }
});
